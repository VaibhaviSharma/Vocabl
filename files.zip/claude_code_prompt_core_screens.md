# Prompt for Claude Code: Vocabl Core Screens

## Context
Vocabl is a CAT vocabulary web app (React + Vite + Supabase). The word content pipeline is already built and the `words` table in Supabase is populated (fields: `word`, `tier`, `correct_definition`, `distractor_definitions`, `hints` (array of 4), `example_sentence`, `source_domain`). I need the core app screens built now, reusing patterns from an earlier project (WordFit) wherever they apply: hangman game mechanic, dynamic attempt formula, pastel card-based UI, custom on-screen keyboard.

No user accounts/auth complexity needed beyond whatever minimal identity Supabase requires to track per-user word status (a simple anonymous/session-based user ID is fine for MVP — no email/password signup flow needed).

Build these four screens/flows, in this order:

## 1. Welcome screen
- Minimal — app name/logo, one-line description, a single "Start" or "Play" button
- No onboarding steps beyond this (no interest picker, no exam selector, no calibration quiz — CAT vocab is the only mode)
- Tapping start takes the user straight to the Home screen

## 2. Home screen
- Pastel, card-based layout (soft colors — pink, teal, coral, amber tones, rounded corners)
- Shows: a "today's word" or "play" card/button that starts a new hangman round, a streak counter, and two quick stats: total words played, and count of words currently flagged "incorrect" (to review)
- A way to navigate to the "My Words" / review screen (quiz mode)
- Keep this screen simple — it's a launchpad, not a dashboard

## 3. Hangman round screen
This is the core loop. Build:
- Word is selected using adaptive difficulty logic (see below), pulled from Supabase
- Context-blank hint shown automatically at the start of the round, no button/tap required — take the word's `example_sentence` and replace the target word with a blank (e.g., "___"), display it above/alongside the keyboard for the whole round
- Custom on-screen keyboard (NOT the native device keyboard) — a grid of tappable letter buttons. Already-guessed letters should visually gray out/disable. This is a deliberate choice for visual consistency across devices and to prevent invalid input.
- Dynamic attempt count based on the word's `tier` — higher tier (harder) words get more allowed wrong guesses than lower tier (easier) words. Use a simple formula like: attempts = 4 + tier (so tier 1 = 5 attempts, tier 5 = 9 attempts) unless you have a stronger formula from the WordFit codebase to reuse — check for it first.
- On round completion (word guessed correctly OR attempts exhausted): show the `correct_definition` and `example_sentence` regardless of outcome, then log the result

### Adaptive difficulty logic (word selection)
- Track a `current_tier` per user (start at tier 1 for new users)
- Serve words using a weighted mix: ~70% at `current_tier`, ~20% one tier below, ~10% one tier above (clamp at tier bounds 1 and 5)
- Track a rolling window of the last 10 words played per user (result: correct/incorrect, and whether max attempts were used)
- If success rate in that window is high (e.g., 80%+ correct with room to spare on attempts), increment `current_tier` by 1 (max 5)
- If success rate is low (e.g., below ~40-50%, or frequently exhausting attempts), decrement `current_tier` by 1 (min 1)
- This logic should run as a simple function that re-evaluates after each round, not a separate batch job

#### Context-blank hint implementation
- The `example_sentence` field contains the word used naturally in a sentence. To build the blanked version: replace the exact word (case-insensitive match, handle basic pluralization/tense variants if the stored sentence doesn't use the base form) with a blank placeholder (e.g., "___").
- Show this blanked sentence automatically at the top of the round — it's not gated behind a button, it's just always visible for the duration of that round.
- Note: the `words` table may also contain a `hints` column (an array of witty/internet-savvy clue variants) from an earlier version of the content pipeline. This field is NOT used for in-round hints anymore — ignore it for the hangman screen. It can be left in the schema unused, or repurposed later for other copy (streak messages, empty states), but should not be surfaced during gameplay.

## Word status logging
- Maintain a table (e.g., `user_word_status`) with `user_id`, `word_id`, `status` (correct/incorrect), `last_attempted_at`
- On every hangman round completion, upsert this row: insert if it doesn't exist for that (user, word) pair, otherwise overwrite `status` and `last_attempted_at` with the latest result
- No attempt history/count needed in v1 — just last-result-wins

## 4. Review / Quiz mode ("My Words")
- Pulls from `user_word_status` for the current user
- Toggle/filter: "All" (every word with a status row) vs. "Incorrect only"
- Quiz format: show the word, present 4 multiple-choice definition options (the correct one + the 3 pre-generated distractors, shuffled), let the user pick one
- On answering, update that word's `status` in `user_word_status` (same upsert logic as hangman — a correct answer here flips status to correct, wrong answer flips it to incorrect)
- Fast-paced, minimal UI — this is meant to feel quicker than hangman, for reinforcement/cramming rather than first-encounter learning

## Design/UX notes
- Reuse WordFit's pastel color palette and card-based layout patterns wherever they exist in the codebase — check for existing shared components/styles before building new ones from scratch
- Reuse WordFit's hangman component and custom keyboard component directly if they're generic enough to repurpose (swap word source, keep the mechanic)
- Keep the overall app feeling fast and lightweight — minimal loading states, no unnecessary animations that slow down repeat play

## Technical notes
- React + Vite, Supabase for data (words table already populated, you'll need to create/confirm the `user_word_status` and any `current_tier`-tracking table)
- No live LLM calls anywhere in these screens — all word content is static, pre-generated, read from Supabase
- Keep components modular so the adaptive difficulty logic and word-status logic can be reused/tested independently of the UI

## Deliverables
- Welcome screen component
- Home screen component
- Hangman round component (with custom keyboard, hint logic, dynamic attempts)
- Review/Quiz mode component
- Word-selection logic (adaptive tier + weighted mix)
- Word-status upsert logic
- Basic routing between all four screens/states
